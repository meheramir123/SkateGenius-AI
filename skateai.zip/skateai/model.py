from __future__ import annotations

import torch
import torch.nn as nn


class PoseQualityNet(nn.Module):
    """Temporal network that predicts a pose quality score in [0, 1]."""

    def __init__(self, input_dim: int = 99, hidden_dim: int = 128, dropout: float = 0.2):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Conv1d(input_dim, hidden_dim, kernel_size=5, padding=2),
            nn.BatchNorm1d(hidden_dim),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Conv1d(hidden_dim, hidden_dim, kernel_size=3, padding=1),
            nn.BatchNorm1d(hidden_dim),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Conv1d(hidden_dim, hidden_dim // 2, kernel_size=3, padding=1),
            nn.BatchNorm1d(hidden_dim // 2),
            nn.SiLU(),
        )
        self.attention = nn.Conv1d(hidden_dim // 2, 1, kernel_size=1)
        self.head = nn.Sequential(
            nn.Linear(hidden_dim // 2, hidden_dim // 4),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 4, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, T, 99]
        x = x.transpose(1, 2)  # [B, 99, T]
        features = self.backbone(x)  # [B, C, T]

        attn_logits = self.attention(features)  # [B, 1, T]
        attn = torch.softmax(attn_logits, dim=-1)
        pooled = torch.sum(features * attn, dim=-1)  # [B, C]

        score_logit = self.head(pooled).squeeze(-1)
        return torch.sigmoid(score_logit)
