from __future__ import annotations

from pathlib import Path
from typing import Dict

import torch
import torch.nn as nn
from torch.optim import AdamW
from tqdm import tqdm

from .dataset import build_dataloaders
from .model import PoseQualityNet
from .utils import ensure_dir, get_device, save_json


def _evaluate(model: nn.Module, loader, device: torch.device, threshold: float) -> Dict[str, float]:
    model.eval()
    mse = nn.MSELoss(reduction="sum")

    total_loss = 0.0
    total_abs_error = 0.0
    total_correct = 0
    total = 0

    with torch.no_grad():
        for batch in loader:
            x = batch["sequence"].to(device)
            target_quality = batch["quality"].to(device)
            target_correct = batch["is_correct"].to(device)

            pred = model(x)
            loss = mse(pred, target_quality)

            total_loss += float(loss.item())
            total_abs_error += float(torch.abs(pred - target_quality).sum().item())

            pred_correct = (pred >= threshold).float()
            total_correct += int((pred_correct == target_correct).sum().item())
            total += x.shape[0]

    if total == 0:
        return {"mse": 0.0, "mae": 0.0, "acc": 0.0}

    return {
        "mse": total_loss / total,
        "mae": total_abs_error / total,
        "acc": total_correct / total,
    }


def train_pose_quality_model(
    manifest_path: Path,
    model_out_path: Path,
    metrics_out_path: Path,
    batch_size: int,
    train_ratio: float,
    val_ratio: float,
    seed: int,
    num_workers: int,
    epochs: int,
    learning_rate: float,
    weight_decay: float,
    threshold: float,
) -> Dict:
    train_loader, val_loader, test_loader, manifest = build_dataloaders(
        manifest_path=manifest_path,
        batch_size=batch_size,
        train_ratio=train_ratio,
        val_ratio=val_ratio,
        seed=seed,
        num_workers=num_workers,
    )

    device = get_device()
    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True

    input_dim = int(manifest.get("feature_dim", 99))
    model = PoseQualityNet(input_dim=input_dim).to(device)
    optimizer = AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)

    mse_loss = nn.MSELoss()
    bce_loss = nn.BCELoss()
    scaler = torch.amp.GradScaler(device.type, enabled=(device.type == "cuda"))

    best_val_mae = float("inf")
    history = []

    for epoch in range(1, epochs + 1):
        model.train()
        running_loss = 0.0

        prog = tqdm(train_loader, desc=f"Epoch {epoch}/{epochs}", leave=False)
        for batch in prog:
            x = batch["sequence"].to(device)
            target_quality = batch["quality"].to(device)
            target_correct = batch["is_correct"].to(device)

            optimizer.zero_grad(set_to_none=True)

            with torch.amp.autocast(device_type=device.type, enabled=(device.type == "cuda")):
                pred = model(x)
                loss_reg = mse_loss(pred, target_quality)

            # BCELoss is not autocast-safe; compute this term in full precision.
            with torch.amp.autocast(device_type=device.type, enabled=False):
                loss_cls = bce_loss(pred.float(), target_correct.float())

            loss = loss_reg + 0.5 * loss_cls

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            running_loss += float(loss.item())
            prog.set_postfix(loss=f"{loss.item():.4f}")

        train_loss = running_loss / max(len(train_loader), 1)
        val_metrics = _evaluate(model, val_loader, device, threshold)

        epoch_info = {
            "epoch": epoch,
            "train_loss": train_loss,
            "val_mse": val_metrics["mse"],
            "val_mae": val_metrics["mae"],
            "val_acc": val_metrics["acc"],
        }
        history.append(epoch_info)

        if val_metrics["mae"] < best_val_mae:
            best_val_mae = val_metrics["mae"]
            ensure_dir(model_out_path.parent)
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "input_dim": input_dim,
                    "threshold": threshold,
                    "class_to_idx": manifest["class_to_idx"],
                    "selected_joint_indices": manifest.get("selected_joint_indices", list(range(33))),
                },
                model_out_path,
            )

        print(
            f"Epoch {epoch:02d} | train_loss={train_loss:.4f} | "
            f"val_mae={val_metrics['mae']:.4f} | val_acc={val_metrics['acc']:.4f}"
        )

    checkpoint = torch.load(model_out_path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    test_metrics = _evaluate(model, test_loader, device, threshold)

    metrics = {
        "device": str(device),
        "split_info": manifest["split_info"],
        "history": history,
        "best_val_mae": best_val_mae,
        "test_metrics": test_metrics,
        "model_path": str(model_out_path.as_posix()),
    }

    ensure_dir(metrics_out_path.parent)
    save_json(metrics_out_path, metrics)
    return metrics
