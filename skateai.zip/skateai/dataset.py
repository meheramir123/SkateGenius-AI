from __future__ import annotations

import random
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from .utils import load_json


class PoseSequenceDataset(Dataset):
    def __init__(self, entries: List[Dict]):
        self.entries = entries

    def __len__(self) -> int:
        return len(self.entries)

    def __getitem__(self, idx: int):
        entry = self.entries[idx]
        sample = np.load(entry["npz_path"])

        sequence = torch.from_numpy(sample["sequence"]).float()
        quality = torch.tensor(float(sample["quality"]), dtype=torch.float32)
        is_correct = torch.tensor(float(sample["is_correct"]), dtype=torch.float32)
        class_idx = torch.tensor(int(sample["class_idx"]), dtype=torch.long)

        return {
            "sequence": sequence,
            "quality": quality,
            "is_correct": is_correct,
            "class_idx": class_idx,
        }


def split_entries_stratified(
    entries: List[Dict],
    train_ratio: float,
    val_ratio: float,
    seed: int,
) -> Tuple[List[Dict], List[Dict], List[Dict]]:
    grouped: Dict[int, List[Dict]] = {}
    for e in entries:
        grouped.setdefault(int(e["class_idx"]), []).append(e)

    rng = random.Random(seed)
    train_entries: List[Dict] = []
    val_entries: List[Dict] = []
    test_entries: List[Dict] = []

    for _, class_entries in grouped.items():
        rng.shuffle(class_entries)
        n = len(class_entries)
        n_train = int(n * train_ratio)
        n_val = int(n * val_ratio)

        train_entries.extend(class_entries[:n_train])
        val_entries.extend(class_entries[n_train : n_train + n_val])
        test_entries.extend(class_entries[n_train + n_val :])

    rng.shuffle(train_entries)
    rng.shuffle(val_entries)
    rng.shuffle(test_entries)

    return train_entries, val_entries, test_entries


def build_dataloaders(
    manifest_path: Path,
    batch_size: int,
    train_ratio: float,
    val_ratio: float,
    seed: int,
    num_workers: int,
) -> Tuple[DataLoader, DataLoader, DataLoader, Dict]:
    manifest = load_json(manifest_path)
    entries = manifest["entries"]

    train_entries, val_entries, test_entries = split_entries_stratified(
        entries=entries,
        train_ratio=train_ratio,
        val_ratio=val_ratio,
        seed=seed,
    )

    train_ds = PoseSequenceDataset(train_entries)
    val_ds = PoseSequenceDataset(val_entries)
    test_ds = PoseSequenceDataset(test_entries)

    pin_memory = torch.cuda.is_available()

    train_loader = DataLoader(
        train_ds,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=pin_memory,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin_memory,
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin_memory,
    )

    split_info = {
        "train": len(train_ds),
        "val": len(val_ds),
        "test": len(test_ds),
    }
    return train_loader, val_loader, test_loader, {**manifest, "split_info": split_info}
