from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import matplotlib.pyplot as plt
import mediapipe as mp
import numpy as np
import torch
from tqdm import tqdm

from .config import LANDMARK_NAMES
from .model import PoseQualityNet
from .pose_extractor import pad_or_trim_sequence
from .utils import ensure_dir, get_device, load_json


class PoseQualityInferencer:
    def __init__(self, model_path: Path):
        self.device = get_device()
        checkpoint = torch.load(model_path, map_location=self.device)

        self.threshold = float(checkpoint.get("threshold", 0.6))
        self.model = PoseQualityNet(input_dim=int(checkpoint.get("input_dim", 99))).to(self.device)
        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.model.eval()
        self.selected_joint_indices = [int(i) for i in checkpoint.get("selected_joint_indices", list(range(33)))]
        self.selected_joint_set = set(self.selected_joint_indices)

        self._mp_pose = mp.solutions.pose
        self._pose = self._mp_pose.Pose(
            static_image_mode=False,
            model_complexity=1,
            enable_segmentation=False,
            smooth_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        )

    @staticmethod
    def _landmarks_to_vector(landmarks: List, selected_joint_indices: List[int]) -> np.ndarray:
        points = np.array([[lm.x, lm.y, lm.z] for lm in landmarks], dtype=np.float32)
        hip_center = (points[23] + points[24]) * 0.5
        shoulder_width = np.linalg.norm(points[11] - points[12])
        scale = max(float(shoulder_width), 1e-3)
        normalized = (points - hip_center) / scale
        normalized = normalized[selected_joint_indices]
        return normalized.reshape(-1)

    def _extract_pose_stream(
        self,
        video_path: Path,
        frame_stride: int,
    ) -> Tuple[np.ndarray, List[np.ndarray], float, Tuple[int, int], List[Optional[np.ndarray]]]:
        cap = cv2.VideoCapture(str(video_path))
        fps = float(cap.get(cv2.CAP_PROP_FPS))
        fps = fps if fps > 0 else 30.0

        vectors: List[np.ndarray] = []
        frames: List[np.ndarray] = []
        landmarks_per_frame: List[Optional[np.ndarray]] = []

        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        frame_idx = 0
        while cap.isOpened():
            ok, frame = cap.read()
            if not ok:
                break

            if frame_idx % frame_stride != 0:
                frame_idx += 1
                continue

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            result = self._pose.process(rgb)

            if result.pose_landmarks is None:
                vectors.append(np.zeros((len(self.selected_joint_indices) * 3,), dtype=np.float32))
                landmarks_per_frame.append(None)
            else:
                landmarks = result.pose_landmarks.landmark
                vectors.append(self._landmarks_to_vector(landmarks, self.selected_joint_indices))
                landmarks_np = np.array([[lm.x, lm.y] for lm in landmarks], dtype=np.float32)
                landmarks_per_frame.append(landmarks_np)

            frames.append(frame)
            frame_idx += 1

        cap.release()

        if vectors:
            seq = np.stack(vectors).astype(np.float32)
        else:
            seq = np.zeros((1, len(self.selected_joint_indices) * 3), dtype=np.float32)

        return seq, frames, fps, (width, height), landmarks_per_frame

    def _draw_skeleton(self, frame: np.ndarray, landmarks: Optional[np.ndarray]) -> np.ndarray:
        if landmarks is None:
            return frame

        h, w = frame.shape[:2]
        out = frame.copy()
        for conn in self._mp_pose.POSE_CONNECTIONS:
            a, b = conn
            if a not in self.selected_joint_set or b not in self.selected_joint_set:
                continue
            xa, ya = landmarks[a]
            xb, yb = landmarks[b]
            pa = (int(xa * w), int(ya * h))
            pb = (int(xb * w), int(yb * h))
            cv2.line(out, pa, pb, (0, 220, 255), 2)

        for idx in self.selected_joint_indices:
            x, y = landmarks[idx]
            cv2.circle(out, (int(x * w), int(y * h)), 2, (0, 255, 0), -1)

        return out

    def infer_video(
        self,
        video_path: Path,
        output_video_path: Path,
        seq_len: int,
        frame_stride: int,
    ) -> Dict[str, object]:
        sequence, frames, fps, (width, height), landmarks_per_frame = self._extract_pose_stream(video_path, frame_stride)
        model_input = pad_or_trim_sequence(sequence, seq_len)

        with torch.no_grad():
            x = torch.from_numpy(model_input).float().unsqueeze(0).to(self.device)
            score = float(self.model(x).item())

        is_correct = score >= self.threshold

        ensure_dir(output_video_path.parent)
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(str(output_video_path), fourcc, fps, (width, height))

        for frame, landmarks in zip(frames, landmarks_per_frame):
            overlaid = self._draw_skeleton(frame, landmarks)
            cv2.putText(
                overlaid,
                f"Pose Score: {score:.3f}",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                (0, 255, 0) if is_correct else (0, 0, 255),
                2,
                cv2.LINE_AA,
            )
            cv2.putText(
                overlaid,
                f"Classification: {'Correct' if is_correct else 'Incorrect'}",
                (20, 70),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 255, 0) if is_correct else (0, 0, 255),
                2,
                cv2.LINE_AA,
            )
            writer.write(overlaid)

        writer.release()

        return {
            "video_path": str(video_path.as_posix()),
            "score": score,
            "is_correct": bool(is_correct),
            "output_video": str(output_video_path.as_posix()),
        }

    def close(self) -> None:
        self._pose.close()

    def extract_key_frames(
        self,
        video_path: Path,
        output_dir: Path,
        seq_len: int,
        frame_stride: int,
        top_k: int = 5,
    ) -> List[str]:
        """Extract the top-k most important frames from a video.

        Each frame is saved as a composite PNG: the annotated video frame on top
        and a per-joint importance bar chart below it.
        """
        joint_names = [LANDMARK_NAMES[i] for i in self.selected_joint_indices]
        num_joints = len(self.selected_joint_indices)

        sequence, frames, fps, (width, height), landmarks_per_frame = self._extract_pose_stream(
            video_path, frame_stride
        )
        T = len(frames)

        model_input = pad_or_trim_sequence(sequence, seq_len)
        x = torch.from_numpy(model_input).float().unsqueeze(0).to(self.device)
        x.requires_grad_(True)

        score = self.model(x)
        self.model.zero_grad(set_to_none=True)
        score.backward()
        score_val = float(score.item())

        # grad: [seq_len, num_joints*3]
        grad = x.grad.detach().abs().squeeze(0).cpu().numpy()

        actual_T = min(T, seq_len)
        # Per-frame scalar importance
        frame_importance = grad[:actual_T].reshape(actual_T, num_joints, 3).mean(axis=(1, 2))
        # Per-frame per-joint importance
        joint_imp_per_frame = grad[:actual_T].reshape(actual_T, num_joints, 3).mean(axis=2)

        k = min(top_k, actual_T)
        top_indices = np.argsort(frame_importance)[-k:][::-1]

        ensure_dir(output_dir)
        saved_paths: List[str] = []
        is_correct = score_val >= self.threshold

        for rank, frame_idx in enumerate(top_indices):
            raw_frame = frames[frame_idx]
            lm = landmarks_per_frame[frame_idx]
            overlaid = self._draw_skeleton(raw_frame, lm)

            # Annotate with score
            cv2.putText(
                overlaid,
                f"Score: {score_val:.3f} | {'Correct' if is_correct else 'Incorrect'}",
                (10, 28),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.75,
                (0, 255, 0) if is_correct else (0, 0, 255),
                2,
                cv2.LINE_AA,
            )

            joint_imp = joint_imp_per_frame[frame_idx]
            joint_imp_norm = joint_imp / max(float(joint_imp.max()), 1e-8)

            fig, (ax_img, ax_bar) = plt.subplots(
                2, 1, figsize=(10, 7), gridspec_kw={"height_ratios": [3, 1], "hspace": 0.4}
            )

            ax_img.imshow(cv2.cvtColor(overlaid, cv2.COLOR_BGR2RGB))
            ax_img.axis("off")
            ax_img.set_title(
                f"{video_path.stem}  |  Rank {rank + 1}  |  Frame {frame_idx}  |  Score: {score_val:.3f}",
                fontsize=9,
            )

            colors = plt.cm.viridis(joint_imp_norm)
            ax_bar.bar(range(num_joints), joint_imp_norm, color=colors, edgecolor="none")
            ax_bar.set_xticks(range(num_joints))
            ax_bar.set_xticklabels(joint_names, rotation=60, ha="right", fontsize=7)
            ax_bar.set_ylabel("Normalised importance", fontsize=8)
            ax_bar.set_ylim(0, 1.05)
            ax_bar.set_title("Joint importance (this frame)", fontsize=8)

            safe_stem = video_path.stem.replace(" ", "_")
            out_path = output_dir / f"{safe_stem}_rank{rank + 1:02d}_frame{frame_idx:04d}.png"
            plt.savefig(out_path, dpi=150, bbox_inches="tight")
            plt.close(fig)
            saved_paths.append(str(out_path.as_posix()))

        return saved_paths

    def infer_all_classes(
        self,
        manifest_path: Path,
        output_videos_dir: Path,
        output_frames_dir: Path,
        seq_len: int,
        frame_stride: int,
        top_k: int = 5,
    ) -> Dict[str, object]:
        """Run inference + key-frame extraction for one representative video per trick class."""
        manifest = load_json(manifest_path)
        entries = manifest["entries"]

        # Keep only the first entry per class
        class_entries: Dict[str, dict] = {}
        for entry in entries:
            cls = entry["class_name"]
            if cls not in class_entries:
                class_entries[cls] = entry

        ensure_dir(output_videos_dir)
        ensure_dir(output_frames_dir)

        results: Dict[str, object] = {}
        for cls, entry in tqdm(sorted(class_entries.items()), desc="Batch inference"):
            video_path = Path(entry["video_path"])
            safe_cls = cls.replace("/", "_").replace(" ", "_")

            out_video = output_videos_dir / f"{safe_cls}_inference.mp4"
            inf_result = self.infer_video(
                video_path=video_path,
                output_video_path=out_video,
                seq_len=seq_len,
                frame_stride=frame_stride,
            )

            frames_dir = output_frames_dir / safe_cls
            frame_paths = self.extract_key_frames(
                video_path=video_path,
                output_dir=frames_dir,
                seq_len=seq_len,
                frame_stride=frame_stride,
                top_k=top_k,
            )

            results[cls] = {**inf_result, "key_frames": frame_paths}

        return results

