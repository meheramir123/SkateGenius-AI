from __future__ import annotations

from pathlib import Path
from typing import Dict

from .config import SkateAIConfig
from .data_pipeline import build_pose_cache
from .heatmap import generate_joint_importance_heatmaps
from .inference import PoseQualityInferencer
from .pose_extractor import MediaPipePoseExtractor
from .train import train_pose_quality_model
from .utils import ensure_dir, load_json, save_json, set_seed


def run_full_pipeline(config: SkateAIConfig) -> Dict:
    set_seed(config.random_seed)

    ensure_dir(config.output_dir)
    ensure_dir(config.cache_dir)

    extractor = MediaPipePoseExtractor(
        quality_threshold=config.pose_threshold,
        selected_landmark_indices=list(config.selected_joint_indices),
    )
    manifest_path = build_pose_cache(
        dataset_root=config.dataset_root,
        cache_dir=config.cache_dir,
        extractor=extractor,
        seq_len=config.seq_len,
        frame_stride=config.frame_stride,
        force_reextract=config.force_reextract,
    )
    extractor.close()

    metrics_path = config.output_dir / "training_metrics.json"
    train_metrics = train_pose_quality_model(
        manifest_path=manifest_path,
        model_out_path=config.model_path,
        metrics_out_path=metrics_path,
        batch_size=config.batch_size,
        train_ratio=config.train_ratio,
        val_ratio=config.val_ratio,
        seed=config.random_seed,
        num_workers=config.num_workers,
        epochs=config.epochs,
        learning_rate=config.learning_rate,
        weight_decay=config.weight_decay,
        threshold=config.pose_threshold,
    )

    heatmap_dir = ensure_dir(config.output_dir / "heatmaps")
    heatmaps = generate_joint_importance_heatmaps(
        manifest_path=manifest_path,
        model_path=config.model_path,
        out_dir=heatmap_dir,
    )

    evidence_dir = ensure_dir(config.output_dir / "evidence")
    videos_dir  = ensure_dir(evidence_dir / "videos")
    frames_dir  = ensure_dir(evidence_dir / "key_frames")

    inferencer = PoseQualityInferencer(config.model_path)
    inference_results = inferencer.infer_all_classes(
        manifest_path=manifest_path,
        output_videos_dir=videos_dir,
        output_frames_dir=frames_dir,
        seq_len=config.seq_len,
        frame_stride=config.frame_stride,
        top_k=5,
    )

    # Also run on the user-supplied or default single video for quick preview
    if config.inference_video is not None:
        manifest = load_json(manifest_path)
        single_video = config.inference_video
    else:
        manifest = load_json(manifest_path)
        single_video = Path(manifest["entries"][0]["video_path"])

    single_inference = inferencer.infer_video(
        video_path=single_video,
        output_video_path=config.inference_output_video,
        seq_len=config.seq_len,
        frame_stride=config.frame_stride,
    )
    inferencer.close()

    report = {
        "manifest": str(manifest_path.as_posix()),
        "model": str(config.model_path.as_posix()),
        "train_metrics": train_metrics,
        "heatmaps": heatmaps,
        "evidence": {
            "videos_dir": str(videos_dir.as_posix()),
            "frames_dir": str(frames_dir.as_posix()),
            "per_class": inference_results,
        },
        "single_inference": single_inference,
    }
    save_json(config.output_dir / "run_report.json", report)
    return report
