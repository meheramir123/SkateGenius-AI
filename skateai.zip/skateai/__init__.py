from .config import LANDMARK_NAMES, SkateAIConfig

__all__ = ["LANDMARK_NAMES", "SkateAIConfig"]
