from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

import cv2
import mediapipe as mp
import numpy as np


@dataclass
class PoseExtractionResult:
    sequence: np.ndarray
    visibility: np.ndarray
    quality_score: float
    is_correct: int


class MediaPipePoseExtractor:
    """Extracts 33-landmark pose keypoints and converts them into 99D vectors."""

    def __init__(
        self,
        static_image_mode: bool = False,
        model_complexity: int = 1,
        min_detection_confidence: float = 0.5,
        min_tracking_confidence: float = 0.5,
        quality_threshold: float = 0.6,
        selected_landmark_indices: Optional[List[int]] = None,
    ) -> None:
        self.quality_threshold = quality_threshold
        self.selected_landmark_indices = selected_landmark_indices or list(range(33))
        self.feature_dim = len(self.selected_landmark_indices) * 3
        self._mp_pose = mp.solutions.pose
        self._pose = self._mp_pose.Pose(
            static_image_mode=static_image_mode,
            model_complexity=model_complexity,
            enable_segmentation=False,
            smooth_landmarks=True,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        )

    def close(self) -> None:
        self._pose.close()

    def _landmarks_to_vector(self, landmarks: List, expected_landmarks: int = 33) -> Tuple[np.ndarray, np.ndarray]:
        if landmarks is None or len(landmarks) != expected_landmarks:
            return (
                np.zeros((self.feature_dim,), dtype=np.float32),
                np.zeros((len(self.selected_landmark_indices),), dtype=np.float32),
            )

        points = np.array([[lm.x, lm.y, lm.z] for lm in landmarks], dtype=np.float32)
        visibility = np.array([lm.visibility for lm in landmarks], dtype=np.float32)

        # Normalize around hip center and scale by shoulder width for view invariance.
        hip_center = (points[23] + points[24]) * 0.5
        shoulder_width = np.linalg.norm(points[11] - points[12])
        scale = max(shoulder_width, 1e-3)

        normalized = (points - hip_center) / scale
        normalized = normalized[self.selected_landmark_indices]
        visibility = visibility[self.selected_landmark_indices]
        return normalized.reshape(-1), visibility

    @staticmethod
    def _compute_quality(sequence: np.ndarray, visibility: np.ndarray) -> float:
        if sequence.shape[0] <= 1:
            return 0.0

        frame_visibility = visibility.mean(axis=1)
        confidence = float(frame_visibility.mean())

        valid_frames = (frame_visibility > 0.15).astype(np.float32)
        coverage = float(valid_frames.mean())

        num_joints = sequence.shape[1] // 3
        seq_reshaped = sequence.reshape(sequence.shape[0], num_joints, 3)
        smoothness = float(np.linalg.norm(np.diff(seq_reshaped, axis=0), axis=2).mean())
        smooth_term = float(np.exp(-smoothness))

        score = 0.55 * confidence + 0.25 * coverage + 0.20 * smooth_term
        return float(np.clip(score, 0.0, 1.0))

    def extract_from_video(self, video_path: str, frame_stride: int = 2) -> PoseExtractionResult:
        cap = cv2.VideoCapture(video_path)
        vectors: List[np.ndarray] = []
        visibilities: List[np.ndarray] = []

        frame_idx = 0
        while cap.isOpened():
            ok, frame = cap.read()
            if not ok:
                break

            if frame_idx % frame_stride != 0:
                frame_idx += 1
                continue

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            result = self._pose.process(rgb)

            if result.pose_landmarks is None:
                vec = np.zeros((self.feature_dim,), dtype=np.float32)
                vis = np.zeros((len(self.selected_landmark_indices),), dtype=np.float32)
            else:
                vec, vis = self._landmarks_to_vector(result.pose_landmarks.landmark)

            vectors.append(vec)
            visibilities.append(vis)
            frame_idx += 1

        cap.release()

        if not vectors:
            sequence = np.zeros((1, self.feature_dim), dtype=np.float32)
            visibility = np.zeros((1, len(self.selected_landmark_indices)), dtype=np.float32)
            quality = 0.0
        else:
            sequence = np.stack(vectors).astype(np.float32)
            visibility = np.stack(visibilities).astype(np.float32)
            quality = self._compute_quality(sequence, visibility)

        is_correct = int(quality >= self.quality_threshold)
        return PoseExtractionResult(sequence=sequence, visibility=visibility, quality_score=quality, is_correct=is_correct)


def pad_or_trim_sequence(sequence: np.ndarray, seq_len: int) -> np.ndarray:
    if sequence.shape[0] == seq_len:
        return sequence

    if sequence.shape[0] > seq_len:
        return sequence[:seq_len]

    pad_len = seq_len - sequence.shape[0]
    padding = np.zeros((pad_len, sequence.shape[1]), dtype=sequence.dtype)
    return np.concatenate([sequence, padding], axis=0)
