from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
from tqdm import tqdm

from .pose_extractor import MediaPipePoseExtractor, pad_or_trim_sequence
from .utils import ensure_dir, save_json


VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv"}


def discover_videos(dataset_root: Path) -> List[Tuple[str, Path]]:
    videos: List[Tuple[str, Path]] = []
    for class_dir in sorted(dataset_root.iterdir()):
        if not class_dir.is_dir():
            continue

        class_name = class_dir.name
        for video_path in sorted(class_dir.rglob("*")):
            if video_path.suffix.lower() in VIDEO_EXTENSIONS:
                videos.append((class_name, video_path))

    return videos


def build_pose_cache(
    dataset_root: Path,
    cache_dir: Path,
    extractor: MediaPipePoseExtractor,
    seq_len: int,
    frame_stride: int,
    force_reextract: bool = False,
) -> Path:
    ensure_dir(cache_dir)
    sample_dir = ensure_dir(cache_dir / "samples")

    videos = discover_videos(dataset_root)
    class_names = sorted({class_name for class_name, _ in videos})
    class_to_idx: Dict[str, int] = {name: i for i, name in enumerate(class_names)}

    entries = []
    selected_joint_indices = list(extractor.selected_landmark_indices)
    feature_dim = len(selected_joint_indices) * 3

    for sample_id, (class_name, video_path) in enumerate(tqdm(videos, desc="Extracting poses")):
        npz_name = f"sample_{sample_id:05d}.npz"
        npz_path = sample_dir / npz_name

        if npz_path.exists() and not force_reextract:
            data = np.load(npz_path)
            quality = float(data["quality"])
            is_correct = int(data["is_correct"])
        else:
            result = extractor.extract_from_video(str(video_path), frame_stride=frame_stride)
            sequence = pad_or_trim_sequence(result.sequence, seq_len)

            np.savez_compressed(
                npz_path,
                sequence=sequence.astype(np.float32),
                quality=np.float32(result.quality_score),
                is_correct=np.int64(result.is_correct),
                class_idx=np.int64(class_to_idx[class_name]),
            )
            quality = result.quality_score
            is_correct = result.is_correct

        entries.append(
            {
                "sample_id": sample_id,
                "class_name": class_name,
                "class_idx": class_to_idx[class_name],
                "video_path": str(video_path.as_posix()),
                "npz_path": str(npz_path.as_posix()),
                "quality": quality,
                "is_correct": is_correct,
            }
        )

    manifest = {
        "dataset_root": str(dataset_root.as_posix()),
        "num_samples": len(entries),
        "num_classes": len(class_names),
        "selected_joint_indices": selected_joint_indices,
        "feature_dim": feature_dim,
        "class_to_idx": class_to_idx,
        "entries": entries,
    }

    manifest_path = cache_dir / "manifest.json"
    save_json(manifest_path, manifest)
    return manifest_path
