from __future__ import annotations

from pathlib import Path
from typing import Dict

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch
from tqdm import tqdm

from .config import LANDMARK_NAMES
from .model import PoseQualityNet
from .utils import ensure_dir, get_device, load_json


def _save_heatmap(values: np.ndarray, labels: list[str], title: str, out_path: Path) -> None:
    ensure_dir(out_path.parent)
    plt.figure(figsize=(16, 2.8))
    sns.heatmap(
        values.reshape(1, -1),
        cmap="viridis",
        cbar=True,
        xticklabels=labels,
        yticklabels=["importance"],
    )
    plt.xticks(rotation=75, ha="right", fontsize=8)
    plt.yticks(rotation=0)
    plt.title(title)
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()


def generate_joint_importance_heatmaps(
    manifest_path: Path,
    model_path: Path,
    out_dir: Path,
) -> Dict[str, str]:
    manifest = load_json(manifest_path)
    entries = manifest["entries"]

    device = get_device()
    checkpoint = torch.load(model_path, map_location=device)

    model = PoseQualityNet(input_dim=int(checkpoint.get("input_dim", 99))).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    selected_joint_indices = checkpoint.get("selected_joint_indices", manifest.get("selected_joint_indices", list(range(33))))
    selected_joint_indices = [int(i) for i in selected_joint_indices]
    joint_names = [LANDMARK_NAMES[i] for i in selected_joint_indices]
    num_joints = len(selected_joint_indices)

    class_sums: Dict[str, np.ndarray] = {}
    class_counts: Dict[str, int] = {}
    overall_sum = np.zeros((num_joints,), dtype=np.float64)
    overall_count = 0

    for entry in tqdm(entries, desc="Heatmap saliency"):
        sample = np.load(entry["npz_path"])
        seq = torch.from_numpy(sample["sequence"]).float().unsqueeze(0).to(device)
        seq.requires_grad_(True)

        score = model(seq)
        model.zero_grad(set_to_none=True)
        score.backward()

        grad = seq.grad.detach().abs().squeeze(0).cpu().numpy().reshape(-1, num_joints, 3)
        importance = grad.mean(axis=(0, 2))

        cls = entry["class_name"]
        class_sums.setdefault(cls, np.zeros((num_joints,), dtype=np.float64))
        class_counts.setdefault(cls, 0)

        class_sums[cls] += importance
        class_counts[cls] += 1

        overall_sum += importance
        overall_count += 1

    generated_paths: Dict[str, str] = {}

    if overall_count > 0:
        overall = overall_sum / overall_count
        overall /= np.maximum(overall.max(), 1e-8)
        out_path = out_dir / "overall_joint_importance.png"
        _save_heatmap(overall, joint_names, "Overall Joint Importance", out_path)
        generated_paths["overall"] = str(out_path.as_posix())

    for cls in sorted(class_sums.keys()):
        imp = class_sums[cls] / max(class_counts[cls], 1)
        imp /= np.maximum(imp.max(), 1e-8)
        safe_name = cls.replace("/", "_")
        out_path = out_dir / f"joint_importance_{safe_name}.png"
        _save_heatmap(imp, joint_names, f"Joint Importance - {cls}", out_path)
        generated_paths[cls] = str(out_path.as_posix())

    return generated_paths
