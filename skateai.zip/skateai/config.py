from dataclasses import dataclass
from pathlib import Path
from typing import Optional


LANDMARK_NAMES = [
    "nose",
    "left_eye_inner",
    "left_eye",
    "left_eye_outer",
    "right_eye_inner",
    "right_eye",
    "right_eye_outer",
    "left_ear",
    "right_ear",
    "mouth_left",
    "mouth_right",
    "left_shoulder",
    "right_shoulder",
    "left_elbow",
    "right_elbow",
    "left_wrist",
    "right_wrist",
    "left_pinky",
    "right_pinky",
    "left_index",
    "right_index",
    "left_thumb",
    "right_thumb",
    "left_hip",
    "right_hip",
    "left_knee",
    "right_knee",
    "left_ankle",
    "right_ankle",
    "left_heel",
    "right_heel",
    "left_foot_index",
    "right_foot_index",
]

# Skateboarding-focused joints: upper-body control + hips and full lower-body chain.
IMPORTANT_JOINT_INDICES = [
    11,
    12,
    13,
    14,
    15,
    16,
    23,
    24,
    25,
    26,
    27,
    28,
    29,
    30,
    31,
    32,
]


@dataclass
class SkateAIConfig:
    dataset_root: Path = Path("Tricks")
    cache_dir: Path = Path("artifacts/pose_cache")
    output_dir: Path = Path("artifacts")
    model_path: Path = Path("pose_quality_model.pth")
    inference_output_video: Path = Path("artifacts/inference_overlay.mp4")

    seq_len: int = 64
    frame_stride: int = 2
    train_ratio: float = 0.8
    val_ratio: float = 0.1

    batch_size: int = 16
    num_workers: int = 4
    epochs: int = 20
    learning_rate: float = 1e-3
    weight_decay: float = 1e-4

    pose_threshold: float = 0.6
    random_seed: int = 42
    important_joint_indices: tuple[int, ...] = tuple(IMPORTANT_JOINT_INDICES)

    inference_video: Optional[Path] = None
    force_reextract: bool = False

    @property
    def selected_joint_indices(self) -> tuple[int, ...]:
        return self.important_joint_indices
